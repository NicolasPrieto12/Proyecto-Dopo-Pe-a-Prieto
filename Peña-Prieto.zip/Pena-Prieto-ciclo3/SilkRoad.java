import java.util.*;

/**
 * SilkRoad – Ciclos 1–3 (presentación pulida)
 *
 * - Camino rectangular centrado (baldosa negra con raya blanca).
 * - Tiendas en forma de “casa” (base + techo) centradas en la celda.
 * - Robots circulares centrados SOBRE el borde (no por fuera).
 * - Barra de progreso azul, centrada y estable.
 * - Animación lenta y clara: ~2.5s por paso global.
 *
 * Nota: solve() del Ciclo 3 usa runAutoDay(0) y NO dibuja nada (tests en verde).
 */
public class SilkRoad {

    // ---- Layout base (ajusta si quieres centrar más) ----
    private static final int ORIGIN_X = 240;   // mueve todo a la derecha/izquierda
    private static final int ORIGIN_Y = 160;   // mueve todo arriba/abajo

    // Tamaños de rejilla y baldosas
    private static final int CELL = 24;        // separación entre celdas
    private static final int TILE = 20;        // baldosa negra
    private static final int DASH_W = 8, DASH_H = 2; // línea blanca

    // Tamaños de tienda (casa)
    private static final int HOUSE_BASE_W = 18, HOUSE_BASE_H = 10;
    private static final int HOUSE_ROOF_W = 18, HOUSE_ROOF_H = 8;

    // Robot
    private static final int ROBOT_D = 12;

    // Estado lógico
    private final int length;
    private final Map<Integer, Store> stores = new HashMap<>();
    private final Map<Integer, Robot> robots = new HashMap<>();
    private long collectedToday = 0, costToday = 0;

    // Dibujo/UI
    private boolean visible = false;
    private Rectangle barBg, barFill;
    private int cols, rows;
    private boolean blinkPhase = false;        // parpadeo del robot “top”
    private final Random rnd = new Random(7);

    // ---------- constructor / factory ----------
    public SilkRoad(int length) {
        if (length < 4) throw new IllegalArgumentException("Longitud mínima: 4");
        this.length = length;
        computeBestRectangle();
    }

    /** Crea desde los arreglos de maratón (Ciclo 3). */
    public static SilkRoad create(int[] storeTenges, int[] robotHomes) {
        SilkRoad sr = new SilkRoad(storeTenges.length);
        for (int i = 0; i < storeTenges.length; i++) if (storeTenges[i] > 0) sr.addStore(i, storeTenges[i]);
        for (int h : robotHomes) sr.addRobot(h);
        return sr;
    }

    // ======================================================
    // =============== CICLO 1 – operaciones =================
    // ======================================================
    public boolean addStore(int x, int tengesInicial) {
        x = normalize(x);
        if (tengesInicial < 0 || stores.containsKey(x)) return false;
        stores.put(x, new Store(x, tengesInicial, randomColorNoBlack()));
        redraw();
        return true;
    }

    public boolean removeStore(int x) {
        x = normalize(x);
        if (stores.remove(x) == null) return false;
        redraw();
        return true;
    }

    public void resupplyStores() {
        for (Store s : stores.values()) s.resupply();
        collectedToday = costToday = 0;
        updateProgressBar();
        redraw();
    }

    public boolean addRobot(int homeX) {
        homeX = normalize(homeX);
        if (robots.containsKey(homeX)) return false;
        Robot r = new Robot(homeX, randomColorNoBlack());
        r.moveTo(homeX);                 // aparece en su casa
        robots.put(homeX, r);
        redraw();
        return true;
    }

    public boolean removeRobot(int homeX) {
        homeX = normalize(homeX);
        if (robots.remove(homeX) == null) return false;
        redraw();
        return true;
    }

    public void returnRobots() {
        for (Robot r : robots.values()) r.returnHome();
        redraw();
    }

    /** Movimiento manual con registro de costo/ganancia. */
    public boolean moveRobotTo(int homeX, int toX) {
        homeX = normalize(homeX); toX = normalize(toX);
        Robot r = robots.get(homeX);
        if (r == null) return false;

        int from = r.getPosition();
        int dist = Math.abs(from - toX);
        r.moveTo(toX);
        costToday += dist;

        int got = 0;
        Store s = stores.get(toX);
        if (s != null) got = s.collectAllToday();
        collectedToday += got;

        r.addMove(from, toX, dist, got);
        updateProgressBar();
        redraw();
        return true;
    }

    public void reboot() {
        for (Store s : stores.values()) s.resupply();
        for (Robot r : robots.values()) r.returnHome();
        collectedToday = costToday = 0;
        updateProgressBar();
        redraw();
    }

    public long getCurrentProfit() { return collectedToday - costToday; }

    // ======================================================
    // =============== CICLO 2 – automático ==================
    // ======================================================
    /** Elige mejor destino por (tenges disponibles – distancia). */
    public boolean autoMove(int homeX) {
        homeX = normalize(homeX);
        Robot r = robots.get(homeX);
        if (r == null) return false;

        int pos = r.getPosition();
        int bestX = -1, bestGain = Integer.MIN_VALUE;

        for (Store s : stores.values()) {
            int avail = (s.isEmptiedToday() ? 0 : s.getCurrentTenges());
            int gain = avail - Math.abs(pos - s.getX());
            if (gain > bestGain || (gain == bestGain && tieBreak(pos, s.getX(), bestX))) {
                bestGain = gain; bestX = s.getX();
            }
        }
        return (bestGain > 0) && moveRobotTo(homeX, bestX);
    }

    /** Un paso global: intenta mover 1 vez cada robot. */
    public int stepAutoAll() {
        int moved = 0;
        ArrayList<Integer> homes = new ArrayList<>(robots.keySet());
        Collections.sort(homes);
        for (int h : homes) if (autoMove(h)) moved++;
        return moved;
    }

    /** Día completo con animación lenta y estable (~2.5 s por paso). */
    public void runAutoDay(int delayMs) {
        int pause = Math.max(2500, delayMs);   // ritmo MUY claro
        while (true) {
            int moved = stepAutoAll();
            toggleBlinkPhase();
            redraw();                           // un repintado por paso
            if (moved == 0) break;
            Canvas.getCanvas().wait(pause);
        }
    }

    /** Versión visible en BlueJ. */
    public void runAutoDay() { runAutoDay(2500); }

    // ======================================================
    // =================== DIBUJO ===========================
    // ======================================================
    public void makeVisible()  { if (!visible) { visible = true; ensureProgressBar(); redraw(); } }
    public void makeInvisible(){ if (visible)  { visible = false; clearCanvas(); } }
    public void finish()       { makeInvisible(); }

    private void redraw() {
        if (!visible) return;
        clearCanvas();
        drawRoad();
        drawStores();
        drawRobots();
        drawProgressBar();
    }

    /** Lienzo blanco base. */
    private void clearCanvas() {
        Rectangle bg = new Rectangle();
        bg.changeColor("white");
        bg.changeSize(1100, 750);
        bg.moveHorizontal(-120);
        bg.moveVertical(-120);
        bg.makeVisible();
    }

    // ----- camino rectangular -----
    private void computeBestRectangle() {
        int bestC = 6, bestR = 6, bestPer = -1;
        for (int c = 6; c <= 30; c++)
            for (int r = 6; r <= 30; r++) {
                int per = 2*(c+r) - 4;
                if (per >= length &&
                   (bestPer == -1 || per < bestPer ||
                   (per == bestPer && Math.abs(c - r) < Math.abs(bestC - bestR)))) {
                    bestPer = per; bestC = c; bestR = r;
                }
            }
        cols = bestC; rows = bestR;
    }

    /** índice de perímetro → celda (fila, col) en sentido horario. */
    private int[] indexToPerimeterCell(int idx) {
        int per = 2*(cols+rows) - 4;
        idx = ((idx % per) + per) % per;
        if (idx < cols) return new int[]{0, idx};
        idx -= cols;
        if (idx < rows-1) return new int[]{1+idx, cols-1};
        idx -= (rows-1);
        if (idx < cols-1) return new int[]{rows-1, (cols-2)-idx};
        idx -= (cols-1);
        return new int[]{(rows-2)-idx, 0};
    }

    /** centro (px) de la celda de perímetro. */
    private int[] indexToTileCenter(int i) {
        int[] rc = indexToPerimeterCell(i);
        return new int[]{ ORIGIN_X + rc[1]*CELL + TILE/2,
                          ORIGIN_Y + rc[0]*CELL + TILE/2 };
    }

    private void drawRoad() {
        for (int i = 0; i < length; i++) {
            int[] c = indexToTileCenter(i);
            // baldosa
            Rectangle tile = makeRect(c[0]-TILE/2, c[1]-TILE/2, TILE, TILE, "black"); tile.makeVisible();
            // línea blanca
            Rectangle dash = makeRect(c[0]-DASH_W/2, c[1]-DASH_H/2, DASH_W, DASH_H, "white"); dash.makeVisible();
        }
    }

    // ----- tiendas y robots -----
    private void drawStores() {
        for (Store s : stores.values()) {
            int[] c = indexToTileCenter(s.getX());
            int cx = c[0], cy = c[1];

            String baseColor = (s.getCurrentTenges() > 0 && !s.isEmptiedToday()) ? s.getColor() : "white";
            Rectangle base = makeRect(cx - HOUSE_BASE_W/2, cy - HOUSE_BASE_H/2, HOUSE_BASE_W, HOUSE_BASE_H, baseColor);
            base.makeVisible();

            Triangle roof = new Triangle();
            roof.changeColor("white");
            roof.changeSize(HOUSE_ROOF_H, HOUSE_ROOF_W);                // alto, ancho
            roof.moveHorizontal((cx - HOUSE_ROOF_W/2) - 130);           // offsets finos
            roof.moveVertical((cy - HOUSE_BASE_H/2 - HOUSE_ROOF_H) - 20);
            roof.makeVisible();
        }
    }

    private void drawRobots() {
        int top = topProfit();
        for (Robot r : robots.values()) {
            int logical = normalize(r.getPosition());
            int[] c = indexToTileCenter(logical);
            String color = (isTop(r, top) && blinkPhase) ? "yellow" : r.getColor();
            Circle dot = makeCircle(c[0]-ROBOT_D/2, c[1]-ROBOT_D/2, ROBOT_D, color);
            dot.makeVisible();
        }
    }

    // ----- barra de progreso -----
    private int barY() { return ORIGIN_Y + rows*CELL + 24; }
    private int barX() { int w = cols*CELL; return ORIGIN_X + (w - 220)/2; }

    private void ensureProgressBar() {
        int y = barY(), x = barX();
        barBg   = makeRect(x, y, 220, 12, "black"); barBg.makeVisible();
        barFill = makeRect(x, y,   1, 12, "blue");  barFill.makeVisible();
        updateProgressBar();
    }

    private void drawProgressBar() { if (visible) { barBg.makeVisible(); updateProgressBar(); } }

    private void updateProgressBar() {
        if (!visible) return;
        long max = 0;
        for (Store s : stores.values()) max += s.getInitialTenges();
        if (max <= 0) max = 1;
        long cur = Math.max(0, getCurrentProfit());
        int w = (int)Math.round(220.0 * Math.min(1.0, (double)cur / (double)max));
        barFill = makeRect(barX(), barY(), Math.max(1, w), 12, "blue");
        barFill.makeVisible(); barBg.makeVisible();
    }

    // ======================================================
    // =================== utilidades =======================
    // ======================================================
    private int  normalize(int x) { return ((x % length) + length) % length; }

    private String randomColorNoBlack() {
        String[] c = {"red","green","blue","magenta"};  // sin negro/amarillo
        return c[rnd.nextInt(c.length)];
    }

    // offsets EXACTOS para BlueJ shapes por defecto
    private Rectangle makeRect(int x,int y,int w,int h,String color){
        Rectangle r = new Rectangle();
        r.changeColor(color);
        r.changeSize(h, w);             // (alto, ancho)
        r.moveHorizontal(x - 70);       // Rectangle default (70,15)
        r.moveVertical(y - 15);
        return r;
    }

    private Circle makeCircle(int x,int y,int d,String color){
        Circle c = new Circle();
        c.changeColor(color);
        c.changeSize(d);
        c.moveHorizontal(x - 20);       // Circle default (20,15)
        c.moveVertical(y - 15);
        return c;
    }

    private boolean tieBreak(int pos, int cand, int best) {
        if (best < 0) return true;
        int dNew = Math.abs(pos - cand), dBest = Math.abs(pos - best);
        if (dNew != dBest) return dNew < dBest;
        return cand < best; // más a la izquierda en empate
    }

    private int  topProfit() { int t = Integer.MIN_VALUE; for (Robot r : robots.values()) t = Math.max(t, (int)r.getTotalProfit()); return t==Integer.MIN_VALUE?0:t; }
    private boolean isTop(Robot r, int t) { return r!=null && (int)r.getTotalProfit()==t; }
    private void toggleBlinkPhase(){ blinkPhase = !blinkPhase; }

    // ======= info (opcional) =======
    public String getInfo() {
        return "Len=" + length + " Stores=" + stores.size() + " Robots=" + robots.size()
             + " Profit=" + getCurrentProfit();
    }
}
