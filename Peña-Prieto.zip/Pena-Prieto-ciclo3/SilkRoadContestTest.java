import static org.junit.Assert.*;
import org.junit.Test;

public class SilkRoadContestTest {

    @Test
    public void deberiaCalcularGananciaPositiva() {
        int[] tiendas = {30, 0, 40, 60, 0};
        int[] robots = {0, 2};
        long utilidad = SilkRoadContest.solve(tiendas, robots);
        System.out.println("[P1] Ganancia calculada = " + utilidad);
        assertTrue("La ganancia debe ser positiva", utilidad > 0);
    }

    @Test
    public void deberiaDarCeroSiNoHayTiendas() {
        int[] tiendas = {0,0,0,0,0};
        int[] robots = {0,2};
        long utilidad = SilkRoadContest.solve(tiendas, robots);
        System.out.println("[P2] Ganancia calculada = " + utilidad);
        assertEquals("Sin tiendas, utilidad debe ser 0", 0, utilidad);
    }

    @Test
    public void deberiaCompararEscenarios() {
        int[] tiendas1 = {20,40,0,50,0};
        int[] tiendas2 = {0,0,0,0,0};
        int[] robots = {0,3};
        long u1 = SilkRoadContest.solve(tiendas1, robots);
        long u2 = SilkRoadContest.solve(tiendas2, robots);
        System.out.println("[P3] Escenario1=" + u1 + " Escenario2=" + u2);
        assertTrue("El escenario 1 debe ser mejor que el 2", u1 > u2);
    }
}
