import java.util.ArrayList;
import java.util.List;

public class Robot {
    public static class Move {
        public final int from, to, distance, collected;
        public final long deltaProfit;
        public Move(int from, int to, int distance, int collected) {
            this.from = from; this.to = to; this.distance = distance; this.collected = collected;
            this.deltaProfit = (long)collected - distance;
        }
    }

    private final int home;
    private int position;
    private final String color;
    private long totalProfit = 0;
    private final List<Move> history = new ArrayList<>();

    public Robot(int home, String color) {
        this.home = home;
        this.position = home;
        this.color = color;
    }

    public int getHome() { return home; }
    public int getPosition() { return position; }
    public String getColor() { return color; }
    public long getTotalProfit() { return totalProfit; }
    public List<Move> getHistory() { return history; }

    public void moveTo(int x) { this.position = x; }
    public void returnHome() { this.position = home; }

    /** Registra un movimiento y acumula ganancia total del robot. */
    public void addMove(int from, int to, int distance, int collected) {
        Move m = new Move(from, to, distance, collected);
        history.add(m);
        totalProfit += m.deltaProfit;
    }
}
