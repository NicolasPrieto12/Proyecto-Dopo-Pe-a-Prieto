import java.util.*;

/**
 * SilkRoad – Ciclos 1–3
 * - Camino rectangular (perímetro) con baldosa negra y línea blanca horizontal, fina y centrada.
 * - Barra de progreso AZUL, horizontal y centrada debajo del camino.
 * - Tiendas con forma de “casa” (base + techo) centradas en la celda.
 * - Robots circulares centrados en la celda.
 * - FIX ciclo 3: al CREAR un robot se posiciona en su HOME (sobre el camino).
 */
public class SilkRoad {

    // ====== Constantes de dibujo
    private static final int ORIGIN_X = 120;
    private static final int ORIGIN_Y = 100;
    private static final int CELL     = 20;
    private static final int TILE     = 18;

    // Demarcación (fina y centrada)
    private static final int DASH_W = 8;
    private static final int DASH_H = 2;

    // Tamaños de tienda (casa) y robot
    private static final int HOUSE_BASE_W = 16;
    private static final int HOUSE_BASE_H = 10;
    private static final int HOUSE_ROOF_W = 16;
    private static final int HOUSE_ROOF_H = 8;
    private static final int ROBOT_D      = 12;

    // ====== Estado
    private final int length;
    private final Map<Integer, Store> stores = new HashMap<>();
    private final Map<Integer, Robot> robots = new HashMap<>();

    // Métricas del día
    private long collectedToday = 0;
    private long costToday = 0;

    // UI
    private boolean visible = false;
    private final Random rnd = new Random(7);

    // Barra de progreso
    private Rectangle barBg;
    private Rectangle barFill;

    // Layout del rectángulo
    private int cols;
    private int rows;

    // ===== Constructores / Factory
    public SilkRoad(int length) {
        if (length < 4) throw new IllegalArgumentException("Longitud mínima: 4");
        this.length = length;
        computeLayout();
    }

    /** Crea desde entrada tipo maratón. */
    public static SilkRoad create(int[] storeTenges, int[] robotHomes) {
        SilkRoad sr = new SilkRoad(storeTenges.length);
        for (int i = 0; i < storeTenges.length; i++) {
            if (storeTenges[i] > 0) sr.addStore(i, storeTenges[i]);
        }
        for (int h : robotHomes) sr.addRobot(h);
        return sr;
    }

    // ===== Stores
    public boolean addStore(int x, int tengesInicial) {
        if (tengesInicial < 0) return false;
        x = normalize(x);
        if (stores.containsKey(x)) return false;
        stores.put(x, new Store(x, tengesInicial, randomColorNoBlack()));
        redraw();
        return true;
    }

    public boolean removeStore(int x) {
        x = normalize(x);
        Store s = stores.remove(x);
        if (s == null) return false;
        redraw();
        return true;
    }

    public void resupplyStores() {
        for (Store s : stores.values()) s.resupply();
        collectedToday = 0; costToday = 0;
        updateProgressBar();
        redraw();
    }

    // ===== Robots
    public boolean addRobot(int homeX) {
        homeX = normalize(homeX);
        if (robots.containsKey(homeX)) return false;
        Robot r = new Robot(homeX, randomColorNoBlack());
        // >>> FIX: el robot se ubica inmediatamente en su casa (sobre el camino)
        r.moveTo(homeX);
        robots.put(homeX, r);
        redraw();
        return true;
    }

    public boolean removeRobot(int homeX) {
        homeX = normalize(homeX);
        Robot r = robots.remove(homeX);
        if (r == null) return false;
        redraw();
        return true;
    }

    public void returnRobots() {
        for (Robot r : robots.values()) r.returnHome();
        redraw();
    }

    // ===== Movimiento manual (con historial para Req.13)
    public boolean moveRobotTo(int homeX, int toX) {
        homeX = normalize(homeX);
        toX   = normalize(toX);

        Robot r = robots.get(homeX);
        if (r == null) return false;

        int fromPos = r.getPosition();
        int dist = Math.abs(fromPos - toX);
        r.moveTo(toX);
        costToday += dist;

        int got = 0;
        Store s = stores.get(toX);
        if (s != null) got = s.collectAllToday();
        collectedToday += got;

        r.addMove(fromPos, toX, dist, got);
        updateProgressBar();
        redraw();
        return true;
    }

    // ===== Movimiento “inteligente” (Req.11)
    public boolean autoMove(int homeX) {
        homeX = normalize(homeX);
        Robot r = robots.get(homeX);
        if (r == null) return false;

        int pos = r.getPosition();
        int bestX = -1;
        int bestGain = Integer.MIN_VALUE;

        for (Store s : stores.values()) {
            int avail = (s.isEmptiedToday() || s.getCurrentTenges() == 0) ? 0 : s.getCurrentTenges();
            int gain = avail - Math.abs(pos - s.getX());
            if (gain > bestGain || (gain == bestGain && gain > 0 && tieBetter(pos, s.getX(), bestX))) {
                bestGain = gain; bestX = s.getX();
            }
        }
        if (bestX < 0 || bestGain <= 0) return false;
        return moveRobotTo(homeX, bestX);
    }

    public int stepAutoAll() {
        int moved = 0;
        ArrayList<Integer> homes = new ArrayList<>(robots.keySet());
        Collections.sort(homes);
        for (int h : homes) if (autoMove(h)) moved++;
        return moved;
    }

    public void autoMoveAll() { while (stepAutoAll() > 0) {} }

    public void runAutoDay(int delayMs) {
        while (true) {
            int m = stepAutoAll();
            if (m == 0) break;
            if (delayMs > 0) try { Thread.sleep(Math.max(20, delayMs)); } catch (InterruptedException ignore) {}
        }
    }

    // ===== Reboot
    public void reboot() {
        for (Store s : stores.values()) s.resupply();
        for (Robot r : robots.values()) r.returnHome();
        collectedToday = 0; costToday = 0;
        updateProgressBar();
        redraw();
    }

    // ===== Consultas
    public long getCurrentProfit() { return collectedToday - costToday; }

    public Map<Integer,Integer> getStoresEmptyCounts() {
        Map<Integer,Integer> res = new TreeMap<>();
        for (Store s : stores.values()) res.put(s.getX(), s.getEmptiedTimes());
        return res;
    }

    public String getRobotMovesReport() {
        StringBuilder sb = new StringBuilder();
        ArrayList<Integer> homes = new ArrayList<>(robots.keySet());
        Collections.sort(homes);
        for (int h : homes) {
            Robot r = robots.get(h);
            sb.append("Robot home=").append(h).append(" totalProfit=").append(r.getTotalProfit()).append("\n");
            for (Robot.Move m : r.getHistory()) {
                sb.append("  from ").append(m.from).append(" -> ").append(m.to)
                  .append(" | dist=").append(m.distance)
                  .append(" collected=").append(m.collected)
                  .append(" delta=").append(m.deltaProfit).append("\n");
            }
        }
        return sb.toString();
    }

    public Map<Integer,Long> getRobotTotalProfits() {
        Map<Integer,Long> res = new TreeMap<>();
        for (Robot r : robots.values()) res.put(r.getHome(), r.getTotalProfit());
        return res;
    }

    // ===== Visibilidad
    public void makeVisible()  { if (!visible) { visible = true; ensureProgressBar(); redraw(); } }
    public void makeInvisible(){ if (visible)  { visible = false; clearCanvas(); } }
    public void finish()       { makeInvisible(); }

    public String getInfo() {
        return "Len=" + length + " Stores=" + stores.size() + " Robots=" + robots.size()
             + " Profit=" + getCurrentProfit();
    }

    // =================== Dibujo ===================
    private void redraw() {
        if (!visible) return;
        clearCanvas();
        drawRoadPerimeter();
        drawStores();
        drawRobots();
        drawProgressBar();
    }

    /** Limpia: rectángulo blanco grande. */
    private void clearCanvas() {
        Rectangle bg = new Rectangle();
        bg.changeColor("white");
        bg.changeSize(900, 700);
        bg.moveHorizontal(-80);
        bg.moveVertical(-80);
        bg.makeVisible();
    }

    // ---------- Layout del rectángulo ----------
    private void computeLayout() {
        int bestC = 6, bestR = 6, bestPer = -1;
        int target = length;
        for (int c = 6; c <= 30; c++) {
            for (int r = 6; r <= 30; r++) {
                int per = 2 * (c + r) - 4; // perímetro sin repetir esquinas
                if (per >= target) {
                    if (bestPer == -1 || per < bestPer ||
                        (per == bestPer && Math.abs(c - r) < Math.abs(bestC - bestR))) {
                        bestPer = per; bestC = c; bestR = r;
                    }
                }
            }
        }
        cols = bestC; rows = bestR;
    }

    /** Índice de perímetro -> (row, col). Recorrido horario desde (0,0). */
    private int[] indexToPerimeterCell(int idx) {
        int per = 2 * (cols + rows) - 4;
        idx = ((idx % per) + per) % per; // normaliza y evita negativos
        if (idx < cols) return new int[]{0, idx};
        idx -= cols;
        if (idx < rows - 1) return new int[]{1 + idx, cols - 1};
        idx -= (rows - 1);
        if (idx < cols - 1) return new int[]{rows - 1, (cols - 2) - idx};
        idx -= (cols - 1);
        return new int[]{(rows - 2) - idx, 0};
    }

    /** Esquina superior-izq (x,y) de la baldosa. */
    private int[] indexToTileTopLeft(int idx) {
        int[] rc = indexToPerimeterCell(idx);
        int row = rc[0], col = rc[1];
        int px = ORIGIN_X + col * CELL;
        int py = ORIGIN_Y + row * CELL;
        return new int[]{px, py};
    }

    /** Centro (x,y) exacto de la baldosa. */
    private int[] indexToTileCenter(int idx) {
        int[] tl = indexToTileTopLeft(idx);
        return new int[]{ tl[0] + TILE/2, tl[1] + TILE/2 };
    }

    // ---------- Dibujo del camino ----------
    private void drawRoadPerimeter() {
        for (int i = 0; i < length; i++) {
            int[] tl = indexToTileTopLeft(i);
            int x = tl[0], y = tl[1];

            // Baldosa negra (18x18)
            Rectangle tile = makeRect(x, y, TILE, TILE, "black", true);
            tile.makeVisible();

            // Línea blanca horizontal, fina y centrada
            Rectangle dash = makeRect(
                x + TILE/2 - DASH_W/2,
                y + TILE/2 - DASH_H/2,
                DASH_W,
                DASH_H,
                "white",
                true
            );
            dash.makeVisible();
        }
    }

    // ---------- Dibujo de tiendas (CASA) y robots ----------
    private void drawStores() {
        for (Store s : stores.values()) {
            int[] c = indexToTileCenter(s.getX());
            int cx = c[0], cy = c[1];

            String baseColor = (s.getCurrentTenges() > 0 && !s.isEmptiedToday()) ? s.getColor() : "white";

            // Base rectangular (centrada)
            int bx = cx - HOUSE_BASE_W/2;
            int by = cy - HOUSE_BASE_H/2 + 1;
            Rectangle base = makeRect(bx, by, HOUSE_BASE_W, HOUSE_BASE_H, baseColor, true);
            base.makeVisible();

            // Techo triangular (centrado)
            int tx = cx - HOUSE_ROOF_W/2;
            int ty = by - HOUSE_ROOF_H + 2;
            Triangle roof = new Triangle();
            roof.changeColor("white"); // o "gray"
            roof.changeSize(HOUSE_ROOF_H, HOUSE_ROOF_W); // (alto, ancho)
            roof.moveHorizontal(tx - 60);
            roof.moveVertical(ty - 50);
            roof.makeVisible();
        }
    }

    private void drawRobots() {
        for (Robot r : robots.values()) {
            // >>> Fallback seguro: si la posición no es válida, usa home
            int logical = normalize(r.getPosition());
            if (logical < 0 || logical >= length) logical = normalize(r.getHome());

            int[] c = indexToTileCenter(logical);
            int cx = c[0], cy = c[1];

            Circle dot = makeCircle(cx - ROBOT_D/2, cy - ROBOT_D/2, ROBOT_D, r.getColor());
            dot.makeVisible();
        }
    }

    // ---------- Barra de progreso (AZUL, HORIZONTAL y CENTRADA) ----------
    private int barY() { return ORIGIN_Y + rows * CELL + 16; }
    private int barX() {
        int rectWpx = cols * CELL;
        return ORIGIN_X + (rectWpx - 200) / 2;
    }

    private void ensureProgressBar() {
        int y = barY(), x = barX();
        barBg   = makeRect(x, y, 200, 12, "black", true);
        barBg.makeVisible();
        barFill = makeRect(x, y, 1, 12, "blue", true);
        barFill.makeVisible();
        updateProgressBar();
    }

    private long maxPossibleNow() {
        long sum = 0;
        for (Store s : stores.values()) sum += s.getInitialTenges();
        return Math.max(1, sum);
    }

    private void updateProgressBar() {
        if (!visible) return;
        long max = maxPossibleNow();
        long cur = Math.max(0, getCurrentProfit());
        int w = (int)Math.round(200.0 * Math.min(1.0, (double)cur / (double)max));

        int y = barY(), x = barX();
        barFill = makeRect(x, y, Math.max(1, w), 12, "blue", true);
        barFill.makeVisible();
        barBg.makeVisible();
    }

    private void drawProgressBar() {
        if (!visible) return;
        barBg.makeVisible();
        updateProgressBar();
    }

    // ---------- Utilidades ----------
    private int  normalize(int x) { return ((x % length) + length) % length; }
    private String randomColorNoBlack() {
        String[] colors = {"red","yellow","blue","green","magenta"};
        return colors[rnd.nextInt(colors.length)];
    }

    private Rectangle makeRect(int x, int y, int w, int h, String color, boolean filled) {
        Rectangle r = new Rectangle();
        r.changeColor(color);
        r.changeSize(w, h);
        r.moveHorizontal(x - 60);
        r.moveVertical(y - 50);
        return r;
    }

    private Circle makeCircle(int x, int y, int diameter, String color) {
        Circle c = new Circle();
        c.changeColor(color);
        c.changeSize(diameter);
        c.moveHorizontal(x - 60);
        c.moveVertical(y - 50);
        return c;
    }

    private boolean tieBetter(int pos, int candX, int curBestX) {
        if (curBestX < 0) return true;
        int d1 = Math.abs(pos - curBestX), d2 = Math.abs(pos - candX);
        int a1 = stores.get(curBestX).getCurrentTenges(), a2 = stores.get(candX).getCurrentTenges();
        if (a2 > a1) return true;
        if (a2 < a1) return false;
        if (d2 < d1) return true;
        if (d2 > d1) return false;
        return candX < curBestX;
    }
}
