/**
 * SilkRoadContestCTest – Ciclo 3
 * 
 * Casos de prueba manuales para verificar el funcionamiento del simulador.
 * Muestra resultados en consola y lanza simulaciones visuales.
 * 
 * Este archivo no usa JUnit, se ejecuta directamente (clic derecho → void main()).
 */
public class SilkRoadContestCTest {

    public static void main(String[] args) {
        System.out.println("=== CASOS DE PRUEBA SILKROAD CONTEST ===");

        // ----------------------------------------------------
        // Caso 1: Configuración básica con ganancia positiva
        // ----------------------------------------------------
        int[] tiendas1 = {30, 0, 40, 60, 0};
        int[] robots1 = {0, 2};
        long res1 = SilkRoadContest.solve(tiendas1, robots1);
        System.out.println("Caso 1 → Ganancia esperada positiva: " + res1);

        // ----------------------------------------------------
        // Caso 2: Sin tiendas (utilidad esperada 0)
        // ----------------------------------------------------
        int[] tiendas2 = {0, 0, 0, 0, 0};
        int[] robots2 = {0, 2};
        long res2 = SilkRoadContest.solve(tiendas2, robots2);
        System.out.println("Caso 2 → Ganancia esperada 0: " + res2);

        // ----------------------------------------------------
        // Caso 3: Comparación entre dos escenarios
        // ----------------------------------------------------
        int[] tiendas3a = {10, 0, 20, 40, 0};
        int[] tiendas3b = {0, 0, 0, 0, 0};
        int[] robots3 = {1, 3};
        long u1 = SilkRoadContest.solve(tiendas3a, robots3);
        long u2 = SilkRoadContest.solve(tiendas3b, robots3);
        System.out.println("Caso 3 → Escenario A=" + u1 + " Escenario B=" + u2);

        // ----------------------------------------------------
        // Caso 4: Simulación visual lenta
        // ----------------------------------------------------
        System.out.println("Caso 4 → Simulación visual (ver ventana BlueJ Shapes Demo)");
        int[] tiendas4 = {20, 0, 50, 30, 0};
        int[] robots4 = {0, 2};
        SilkRoadContest.simulate(tiendas4, robots4, 1000);

        // ----------------------------------------------------
        // Caso 5: Demostración grande (20 tiendas y 3 robots)
        // ----------------------------------------------------
        System.out.println("Caso 5 → Demo grande (20 tiendas)");
        SilkRoadContest.demo();

        System.out.println("=== FIN DE LAS PRUEBAS MANUALES ===");
    }
}
