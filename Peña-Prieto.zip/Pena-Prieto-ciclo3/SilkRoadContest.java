/**
 * SilkRoadContest – Ciclo 3
 */
public class SilkRoadContest {

    public static long solve(int[] storeTenges, int[] robotHomes) {
        SilkRoad sr = SilkRoad.create(storeTenges, robotHomes);
        sr.runAutoDay(0);
        return sr.getCurrentProfit();
    }

    public static void simulate(int[] storeTenges, int[] robotHomes, int delayMs) {
        SilkRoad sr = SilkRoad.create(storeTenges, robotHomes);
        sr.makeVisible();
        Canvas.getCanvas().wait(400);
        sr.runAutoDay(Math.max(1000, delayMs));
        System.out.println("Ganancia final: " + sr.getCurrentProfit());
    }

    public static void simulate(int[] storeTenges, int[] robotHomes) {
        simulate(storeTenges, robotHomes, 1200);
    }

    public static void demo() {
        int[] tiendas = {0,10,0,20,0, 40,0,0,0,30, 0,0,0,0,50, 0,0,15,0,25};
        int[] robots  = {0, 7, 12};
        simulate(tiendas, robots, 1200);
    }
}
