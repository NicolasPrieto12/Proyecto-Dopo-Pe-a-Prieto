public class Store {
    private final int x;
    private final int initialTenges;
    private int currentTenges;
    private boolean emptiedToday;
    private final String color;
    private int emptiedTimes; // cuántas veces ha sido vaciada (histórico)

    public Store(int x, int initialTenges, String color) {
        this.x = x;
        this.initialTenges = Math.max(0, initialTenges);
        this.currentTenges = this.initialTenges;
        this.emptiedToday = false;
        this.color = color;
        this.emptiedTimes = 0;
    }

    public int getX() { return x; }
    public int getInitialTenges() { return initialTenges; }
    public int getCurrentTenges() { return currentTenges; }
    public String getColor() { return color; }
    public boolean isEmptiedToday() { return emptiedToday; }
    public int getEmptiedTimes() { return emptiedTimes; }

    /** Vacía la tienda por hoy y retorna lo cobrado; si ya estaba vacía hoy, retorna 0. */
    public int collectAllToday() {
        if (emptiedToday || currentTenges == 0) return 0;
        int got = currentTenges;
        currentTenges = 0;
        emptiedToday = true;
        emptiedTimes++;
        return got;
    }

    /** Nuevo día: vuelve al valor inicial y habilita para cobrar. */
    public void resupply() {
        currentTenges = initialTenges;
        emptiedToday = false;
    }
}
